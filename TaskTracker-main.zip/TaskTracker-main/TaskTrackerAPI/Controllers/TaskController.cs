// Controllers/TaskController.cs

using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using TaskTrackerAPI.Data;
using TaskTrackerAPI.Models;

namespace TaskTrackerAPI.Controllers
{
[ApiController]
[Route("api/v1/[controller]")]
public class TaskController : ControllerBase
{
    private readonly TaskDbContext _dbContext;

    public TaskController(TaskDbContext dbContext)
    {
        _dbContext = dbContext;
    }

    [HttpGet]
    public IEnumerable<TaskItem> GetTasks()
    {
        return  _dbContext.Tasks.ToList();

    }
 
    [HttpGet("{id}")]
        public ActionResult<TaskItem> GetTask(int id)
        {
            var task = _dbContext.Tasks.FirstOrDefault(t => t.Id == id);
            if (task == null)
            {
                return NotFound();
            }
            return task;
        }

    [HttpPost]
    public IActionResult AddTask([FromBody] TaskItem task)
    {

        
        task.DueDate = task.DueDate.ToUniversalTime();

        _dbContext.Tasks.Add(task);
        _dbContext.SaveChanges();
        return Ok(task);
    }

    [HttpGet("activetasks")]
    public async Task<ActionResult<IEnumerable<TaskItem>>> GetActiveTasks()
    {
            var activeTasks = await _dbContext.Tasks
                .Where(task => task.Status.ToLower() != "completed") // Fetch tasks where status is not equal to "Completed"
                .ToListAsync();

            return Ok(activeTasks);
    }
        

    [HttpPut("{id}")]
    public IActionResult UpdateTask(int id, TaskItem updatedTask)
    {
        var task = _dbContext.Tasks.Find(id);

        if (task == null)
            return NotFound();

        
        updatedTask.DueDate = updatedTask.DueDate.ToUniversalTime();
        updatedTask.StartDate = updatedTask.StartDate.ToUniversalTime();
        
        task.Title = updatedTask.Title;
        task.Summary = updatedTask.Summary;
        task.Assignee = updatedTask.Assignee;
        task.Reporter = updatedTask.Reporter;
        task.DueDate = updatedTask.DueDate;
        task.StartDate = updatedTask.StartDate;
        task.Status = updatedTask.Status;

        _dbContext.SaveChanges();

        return Ok(task);
    }

    [HttpDelete("{id}")]
        public IActionResult DeleteTask(int id)
        {
            var task = _dbContext.Tasks.FirstOrDefault(t => t.Id == id);
            if (task == null)
            {
                return NotFound();
            }

            _dbContext.Tasks.Remove(task);
            _dbContext.SaveChanges();

            return NoContent();
        }
}
}