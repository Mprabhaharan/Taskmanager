// Models/TaskItem.cs
using System.ComponentModel.DataAnnotations.Schema;

namespace TaskTrackerAPI.Models
{
    [Table("tasks")]
    public class TaskItem
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Column("id")]
        public int Id { get; set; }

        [Column("title")]
        public string? Title { get; set; }

        [Column("summary")]
        public string? Summary { get; set; }

        [Column("assignee")]
        public string? Assignee { get; set; }

        [Column("reporter")]
        public string? Reporter { get; set; }

        [Column("duedate")]
        public DateTime DueDate { get; set; }

        [Column("startdate")]
        public DateTime StartDate { get; set; }

        [Column("status")]
        public string? Status { get; set; }

    }
}
