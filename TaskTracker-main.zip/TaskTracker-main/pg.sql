CREATE DATABASE tasktracker;
-- public.tasks definition

-- Drop table

-- DROP TABLE tasks;

CREATE TABLE tasks (
	id serial4 NOT NULL,
	title varchar(255) NULL,
	summary varchar(255) NULL,
	assignee varchar(255) NULL,
	reporter varchar(255) NULL,
	duedate timestamp NULL,
	startdate timestamp NULL,
	status varchar(50) NULL,
	CONSTRAINT tasks_pkey null
);