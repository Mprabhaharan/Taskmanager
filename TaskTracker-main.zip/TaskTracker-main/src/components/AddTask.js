//src/components/AddTask.js
import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import { Box, Button, FormControl, InputLabel, MenuItem, Select, TextField } from '@mui/material';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { DateTimePicker } from '@mui/x-date-pickers/DateTimePicker';
import dayjs from "dayjs";
import utc from 'dayjs/plugin/utc';
import timezone from 'dayjs/plugin/timezone';

dayjs.extend(utc);
dayjs.extend(timezone);





const AddTask = () => {
    // const [newTask, setNewTask] = useState({ description: '', dueDate: '', summary: '', username: 'Micheal' });
    const history = useNavigate();

    const [newTask, setNewTask] = useState({ title: '', summary: '', dueDate: new Date(), startDate: new Date(), status: '', assignee: '' });


    const handleAddTask = () => {
        const taskData = {
            ...newTask,
            dueDate: newTask.dueDate.toISOString(), // Convert to UTC format
            startDate: newTask.startDate.toISOString(), // Convert to UTC format
          };
          
        axios.post('http://localhost:5000/api/v1/Task', taskData).then(response => {
            console.log(response.data);
            // Redirect to TaskList page
            history('/');
        }).catch(error => console.error(error));
    };

    return (
        <Box
            component="form"
            sx={{
                '& > :not(style)': { m: 1, width: '25ch' },
            }}
            noValidate
            autoComplete="off"
        >
            
            <TextField
                id="outlined-controlled"
                label="Title"
                value={newTask.title}
                onChange={
                    e => setNewTask({
                        ...newTask,
                        title: e.target.value
                    })}
            />
            <br/>
            <TextField
                id="outlined-multiline-static"
                label="Summary"
                multiline
                rows={4}
                inputProps={{ style: { resize: "both" } }}
                value={newTask.summary}
                onChange={
                    e => setNewTask({
                        ...newTask,
                        summary: e.target.value
                    })}
            />
            <br/>
            <FormControl sx={{ m: 1, minWidth: 120 }}>
                <InputLabel id="demo-simple-select-helper-label">Status</InputLabel>
                <Select
                    labelId="demo-simple-select-helper-label"
                    id="demo-simple-select-helper"
                    value={newTask.status}
                    label="Status"
                    onChange={
                        e => setNewTask({
                            ...newTask,
                            status: e.target.value
                        })}
                >
                    <MenuItem value='Open'>Open</MenuItem>
                    <MenuItem value='In Progress'>In Progress</MenuItem>
                    <MenuItem value='Done'>Completed</MenuItem>
                    <MenuItem value='Blocked'>Blocked</MenuItem>
                </Select>
            </FormControl>
            <br/>
            <FormControl sx={{ m: 1, minWidth: 120 }}>
                <InputLabel id="demo-simple-select-helper-label">Assignee</InputLabel>
                <Select
                    labelId="demo-simple-select-helper-label"
                    id="demo-simple-select-helper"
                    value={newTask.assignee}
                    label="assignee"
                    onChange={
                        e => setNewTask({
                            ...newTask,
                            assignee: e.target.value
                        })}
                >
                    <MenuItem value='John'>John</MenuItem>
                    <MenuItem value='Agnus'>Agnus</MenuItem>
                    <MenuItem value='Derrick'>Derrick</MenuItem>
                    <MenuItem value='Jovanni'>Jovanni</MenuItem>
                </Select>
            </FormControl>
            <FormControl sx={{ m: 1, minWidth: 120 }}>
                <InputLabel id="demo-simple-select-helper-label">Reporter</InputLabel>
                <Select
                    labelId="demo-simple-select-helper-label"
                    id="demo-simple-select-helper"
                    value={newTask.reporter}
                    label="reporter"
                    onChange={
                        e => setNewTask({
                            ...newTask,
                            reporter: e.target.value
                        })}
                >
                    <MenuItem value='John'>John</MenuItem>
                    <MenuItem value='Agnus'>Agnus</MenuItem>
                    <MenuItem value='Derrick'>Derrick</MenuItem>
                    <MenuItem value='Jovanni'>Jovanni</MenuItem>
                </Select>
            </FormControl>
            <br/>
            <br/>
            <LocalizationProvider dateAdapter={AdapterDayjs}>
                <DateTimePicker
                    label="Start Date"
                    value={dayjs(newTask.startDate)}
                    timezone='UTC'
                    onChange={date => setNewTask({ ...newTask, startDate: date })}
                    renderInput={(params) => <TextField {...params} />}          
                    />
            </LocalizationProvider>
            <LocalizationProvider dateAdapter={AdapterDayjs}>
                <DateTimePicker
                    label="Due Date"
                    value={dayjs(newTask.dueDate)}
                    timezone='UTC'
                    onChange={date => setNewTask({ ...newTask, dueDate: date })}
                    renderInput={(params) => <TextField {...params} />}
                    />
            </LocalizationProvider>
            {/* <TextField
                id="datetime-local"
                label="DueDa"
                type="datetime-local"
                // defaultValue="2017-05-24T10:30"
                // className={classes.textField}
                variant="outlined"
                InputLabelProps={{
                    shrink: true,
                }}
                onChange={
                    e => setNewTask({
                        ...newTask,
                        dueDate: e.target.value
                    })}
            /> */}
                        <br/>            <br/>
            <Button variant="contained" onClick={handleAddTask}>Add</Button>
        </Box>
    );
};

export default AddTask;
