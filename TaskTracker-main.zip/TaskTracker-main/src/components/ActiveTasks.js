// src/components/ActiveTasks.js
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { DataGrid } from '@mui/x-data-grid';
import Modal from '@mui/material/Modal';
import Box from '@mui/material/Box';
import TextField from '@mui/material/TextField';
import Button from '@mui/material/Button';
import { useNavigate } from 'react-router-dom';
import { darken, lighten, styled } from '@mui/material/styles';
import { FormControl, InputLabel, MenuItem, Select } from '@mui/material';
import { DateTimePicker, LocalizationProvider } from '@mui/x-date-pickers';
import dayjs from 'dayjs';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
const getBackgroundColor = (color, mode) =>
  mode === 'dark' ? darken(color, 0.7) : lighten(color, 0.7);

const getHoverBackgroundColor = (color, mode) =>
  mode === 'dark' ? darken(color, 0.6) : lighten(color, 0.6);

const getSelectedBackgroundColor = (color, mode) =>
  mode === 'dark' ? darken(color, 0.5) : lighten(color, 0.5);

const getSelectedHoverBackgroundColor = (color, mode) =>
  mode === 'dark' ? darken(color, 0.4) : lighten(color, 0.4);

const StyledDataGrid = styled(DataGrid)(({ theme }) => ({
  '& .super-app-theme--Open': {
    backgroundColor: getBackgroundColor(theme.palette.info.main, theme.palette.mode),
    '&:hover': {
      backgroundColor: getHoverBackgroundColor(
        theme.palette.info.main,
        theme.palette.mode,
      ),
    },
    '&.Mui-selected': {
      backgroundColor: getSelectedBackgroundColor(
        theme.palette.info.main,
        theme.palette.mode,
      ),
      '&:hover': {
        backgroundColor: getSelectedHoverBackgroundColor(
          theme.palette.info.main,
          theme.palette.mode,
        ),
      },
    },
  },
  '& .super-app-theme--Done': {
    backgroundColor: getBackgroundColor(
      theme.palette.success.main,
      theme.palette.mode,
    ),
    '&:hover': {
      backgroundColor: getHoverBackgroundColor(
        theme.palette.success.main,
        theme.palette.mode,
      ),
    },
    '&.Mui-selected': {
      backgroundColor: getSelectedBackgroundColor(
        theme.palette.success.main,
        theme.palette.mode,
      ),
      '&:hover': {
        backgroundColor: getSelectedHoverBackgroundColor(
          theme.palette.success.main,
          theme.palette.mode,
        ),
      },
    },
  },
  '& .super-app-theme--InProgress': {
    backgroundColor: getBackgroundColor(
      theme.palette.warning.main,
      theme.palette.mode,
    ),
    '&:hover': {
      backgroundColor: getHoverBackgroundColor(
        theme.palette.warning.main,
        theme.palette.mode,
      ),
    },
    '&.Mui-selected': {
      backgroundColor: getSelectedBackgroundColor(
        theme.palette.warning.main,
        theme.palette.mode,
      ),
      '&:hover': {
        backgroundColor: getSelectedHoverBackgroundColor(
          theme.palette.warning.main,
          theme.palette.mode,
        ),
      },
    },
  },
  '& .super-app-theme--Blocked': {
    backgroundColor: getBackgroundColor(
      theme.palette.error.main,
      theme.palette.mode,
    ),
    '&:hover': {
      backgroundColor: getHoverBackgroundColor(
        theme.palette.error.main,
        theme.palette.mode,
      ),
    },
    '&.Mui-selected': {
      backgroundColor: getSelectedBackgroundColor(
        theme.palette.error.main,
        theme.palette.mode,
      ),
      '&:hover': {
        backgroundColor: getSelectedHoverBackgroundColor(
          theme.palette.error.main,
          theme.palette.mode,
        ),
      },
    },
  },
}));


const ActiveTasks = () => {
  const [tasks, setTasks] = useState([]);
  const [selectedTask, setSelectedTask] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const history = useNavigate();

  useEffect(() => {
    // Fetch active tasks from the API
    axios.get('http://localhost:5000/api/v1/Task/')
      .then(response => {
        setTasks(response.data);
      })
      .catch(error => console.error(error));
  }, []);

  const handleEditClick = (task) => {
    setSelectedTask(task);
    setIsModalOpen(true);
  };

  const handleModalClose = () => {
    setIsModalOpen(false);
  };

  const handleSaveChanges = () => {
    if (selectedTask) {
      // Make a PUT request to update the task on the server
      axios.put(`http://localhost:5000/api/v1/Task/${selectedTask.id}`, selectedTask)
        .then(response => {
          console.log(response.data);
          // Close the modal after successful update
          setIsModalOpen(false);
          history('/')
          window.location.reload(false);
        })
        .catch(error => console.error(error));
    }
  };

  const columns = [
    { field: 'id', headerName: 'ID', width: 70 },
    { field: 'title', headerName: 'Title', width: 200 },
    { field: 'summary', headerName: 'Summary', width: 200 },
    { field: 'status', headerName: 'Status', width: 120 },
    { field: 'startDate', headerName: 'Start Date', width: 150 },
    { field: 'dueDate', headerName: 'Due Date', width: 150 },
    { field: 'assignee', headerName: 'Assignee', width: 150 },
    { field: 'reporter', headerName: 'Reporter', width: 150 },
    {
      field: 'edit',
      headerName: 'Edit',
      width: 100,
      renderCell: (params) => (
        params.row.status.toLowerCase() !== 'done' && (
          <button onClick={() => handleEditClick(params.row)}>Edit</button>
        )
      ),
    },
  ];

  return (
    <div>
      {/* Table */}
      <div style={{ height: 400, width: '100%' }}>
        <StyledDataGrid
          rows={tasks}
          columns={columns}
          // pageSize={5}
          // rowsPerPageOptions={[5, 10, 20]}
          // checkboxSelection
          {...tasks}
          getRowClassName={(params) => `super-app-theme--${params.row.status}`}
        />
      </div>

      {/* Edit Modal */}
      <Modal
        open={isModalOpen}
        onClose={handleModalClose}
        aria-labelledby="edit-modal-title"
        aria-describedby="edit-modal-description"
      >
        <Box sx={{ position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%, -50%)', width: 400, bgcolor: 'background.paper', boxShadow: 24, p: 4, borderSpacing: 2 }}>
          <h2 id="edit-modal-title">Edit Task</h2>
          {selectedTask && (
            <>
              <TextField label="Title" value={selectedTask.title} onChange={(e) => setSelectedTask({ ...selectedTask, title: e.target.value })} fullWidth sx={{ m: 1 }} />
              <TextField label="Summary" value={selectedTask.summary} onChange={(e) => setSelectedTask({ ...selectedTask, summary: e.target.value })} fullWidth sx={{ m: 1 }} />
              <FormControl sx={{ m: 1, minWidth: 120 }}>
                <InputLabel id="demo-simple-select-helper-label">Status</InputLabel>
                <Select
                  labelId="demo-simple-select-helper-label"
                  id="demo-simple-select-helper"
                  value={selectedTask.status}
                  label="Status"
                  onChange={
                    (e) => setSelectedTask({ ...selectedTask, status: e.target.value })}
                >
                  <MenuItem value='Open'>Open</MenuItem>
                  <MenuItem value='In Progress'>In Progress</MenuItem>
                  <MenuItem value='Done'>Completed</MenuItem>
                  <MenuItem value='Blocked'>Blocked</MenuItem>
                </Select>
              </FormControl>
                <LocalizationProvider dateAdapter={AdapterDayjs}>
                  <DateTimePicker
                    label="Start Date"
                    value={dayjs(selectedTask.startDate)}
                    timezone='UTC'
                    onChange={date => setSelectedTask({ ...selectedTask, startDate: date })}
                    renderInput={(params) => <TextField {...params} />}
                  />
                </LocalizationProvider>
              <TextField label="Assignee" value={selectedTask.assignee} onChange={(e) => setSelectedTask({ ...selectedTask, assignee: e.target.value })} fullWidth sx={{ m: 1 }} />
              <TextField label="Reporter" value={selectedTask.reporter} onChange={(e) => setSelectedTask({ ...selectedTask, reporter: e.target.value })} fullWidth sx={{ m: 1 }} />
              <Button variant="contained" onClick={handleSaveChanges}>Save Changes</Button>
            </>
          )}
        </Box>
      </Modal>
    </div>
  );
};

export default ActiveTasks;
