// src/components/Task.js
import React from 'react';

const Task = ({ task, onUpdate }) => {
  const handleCheckboxChange = () => {
    onUpdate({ ...task, completed: !task.completed });
  };

  return (
    <div>
      <input
        type="checkbox"
        checked={task.completed}
        onChange={handleCheckboxChange}
      />
      <span>{task.description} - Due Date: {task.dueDate}</span>
    </div>
  );
};

export default Task;
