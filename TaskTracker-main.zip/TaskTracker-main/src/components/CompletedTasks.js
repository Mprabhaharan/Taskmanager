// src/components/CompletedTasks.js
import React from 'react';

const CompletedTasks = ({tasks}) => {
    return (
        <div className="completed-tasks">
            <h3>Completed Tasks</h3>
            {
            tasks.map(task => (
                <div key={
                        task.id
                    }
                    className="completed-task-card">
                    <span>{
                        task.description
                    }</span>
                       <p> {
                        task.summary
                    }</p>
                    <br/>
                    <span>Date: {
                        task.dueDate
                    }</span>
                </div>
            ))
        } </div>
    );
};

export default CompletedTasks;
