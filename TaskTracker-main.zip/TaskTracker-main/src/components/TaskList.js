// src/components/TaskList.js
import React, {useState, useEffect} from 'react';
import axios from 'axios';
import ActiveTasks from './ActiveTasks';
import CompletedTasks from './CompletedTasks';

const TaskList = () => {
    const [tasks, setTasks] = useState([]);

    useEffect(() => {
        axios.get('http://localhost:5000/api/v1/Task').then(response => setTasks(response.data)).catch(error => console.error(error));
    }, []);

    const handleMarkAsCompleted = (id) => {
        axios.get(`http://localhost:5000/api/v1/Task/${id}`).then(response => {
            const taskToUpdate = response.data;
            taskToUpdate.completed = true;

            axios.put(`http://localhost:5000/api/v1/Task/${id}`, taskToUpdate).then(response => {
                const updatedTasks = tasks.map(task => (task.id === id ? response.data : task));
                setTasks(updatedTasks);
            }).catch(error => console.error(error));
        }).catch(error => console.error(error));
    };

    return (
        <div className="task-list-container">
            <h2>Task List</h2>
            <div className="tasks-container">
                <ActiveTasks tasks={
                        tasks.filter(task => !task.completed)
                    }
                    onMarkAsCompleted={handleMarkAsCompleted}/> {/* <CompletedTasks tasks={
                    tasks.filter(task => task.completed)
                }/> */} </div>
        </div>
    );
};

export default TaskList;
