// src/App.js
import React, { useEffect } from 'react';
import {BrowserRouter as Router, Route, Link, Routes} from 'react-router-dom';
import TaskList from './components/TaskList';
import AddTask from './components/AddTask';
import './App.css';

const App = () => {
    useEffect(() => {
        document.title = 'Task Tracker';
    })
    return (
        <Router>
            <div>
                <nav>
                    <ul>
                        <li>
                            <Link to="/">Task List</Link>
                        </li>
                        <li>
                            <Link to="/add-task">Add Task</Link>
                        </li>
                    </ul>
                </nav>

                <hr/>

                <Routes>
                    <Route path="/" 
                        element={<TaskList/>}/>
                    <Route path="/add-task"
                        element={<AddTask/>}/>
                </Routes>
            </div>
        </Router>
    );
};

export default App;
