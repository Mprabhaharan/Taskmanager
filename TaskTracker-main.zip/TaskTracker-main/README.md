# Getting Started

Clone the repo and follow the steps

## React app

 ```bash
 cd task-tracker
 npm install
 npm start
 ```

Runs the app in the development mode.\
Open [http://localhost:3000](http://localhost:3000) to view it in your browser.

**ASP.NET**

# Dependencies


```bash
dotnet add package Microsoft.EntityFrameworkCore.Design
dotnet add package Npgsql.EntityFrameworkCore.PostgreSQL
```

*To start API*

```bash
cd TaskTrackerAPI
dotnet run --urls=http://localhost:5000
```
